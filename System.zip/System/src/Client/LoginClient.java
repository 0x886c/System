package Client;

import UI.UI1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class LoginClient extends Thread{
    static Socket socket = null;
    public static void main(String[] args){
        new UI1();//客户端登陆界面显示
    }
    public void run(){//获取来自服务端的输入流
        try {
            InputStream inputStream = socket.getInputStream();
            int len = 0;
            byte[] buf = new byte[1024];
            while ((len=inputStream.read(buf))!=-1){
                System.out.println(new String(buf,0,len));
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static class LoginListener implements ActionListener{
        TextField textFieldId,textFieldName,textFieldClass;
        String Stuid,Stuname,Stuclass;
        Frame loginframe = null;

        //完成UI1中的参数传递

        public void SetTextId(TextField textField){
            textFieldId = textField;
        }
        public void SetTextName(TextField textField){
            textFieldName = textField;
        }
        public void SetTextClass(TextField textField){
            textFieldClass = textField;
        }
        public void SetTextFrame(Frame frame){
            loginframe = frame ;
        }

        //监听界面输入并以字节流的形式将数据发送至服务端

        @Override
        public void actionPerformed(ActionEvent e) {
            Stuid = textFieldId.getText();
            Stuname = textFieldName.getText();
            Stuclass = textFieldClass.getText();
            System.out.println(Stuid+'\n'+Stuname+'\n'+Stuclass);
            try {
                socket = new Socket(InetAddress.getLocalHost(),7777);
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write((Stuid+" "+Stuname+" "+Stuclass+" "+socket.getInetAddress().getHostAddress()).getBytes());
            } catch (UnknownHostException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            LoginClient loginClient = new LoginClient();
            loginClient.start();
        }
    }
}
