package Client;


public class ClientTest {
    public static void main(String[] args) {
        Client client=new Client();
        client.start();
    }
}

