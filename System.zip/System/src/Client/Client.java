package Client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Client extends Thread{
    Socket socket=null;
    public Client(){
        try {
            socket=new Socket(InetAddress.getLocalHost(),7777);
        }catch (UnknownHostException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void run(){
        new WriteMess().start();
        try {
            InputStream inputStream=socket.getInputStream();//获取输入流
            int len=0;
            byte[] buf=new byte[1024];
            while ((len=inputStream.read(buf))!=-1){
                System.out.println(new String(buf,0,len));//格式化后输出
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    class WriteMess extends Thread{
        public void run(){
            Scanner scanner=null;
            OutputStream outputStream=null;
            try {
                scanner=new Scanner(System.in);//获取控制台输入
                outputStream=socket.getOutputStream();//获取输出流
                while (true){
                    String strs=scanner.nextLine();
                    outputStream.write(strs.getBytes());//以输出流的方式输出
                }
            }catch (IOException e){
                e.printStackTrace();
            }
            scanner.close();
            try {
                outputStream.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }
}

