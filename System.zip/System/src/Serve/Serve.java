package Serve;

import java.io.IOException;
import java.io.InputStream;;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Serve extends Thread{
    List<Socket> list=new ArrayList<>();//准备放置多个socket线程
    ServerSocket serverSocket=null;//类内需要得到使用，不要在方法里面才声明，提前声明
    public Serve(int port){
        try {
            serverSocket=new ServerSocket(port);//根据端口实例化，只有在同一个端口的线程才能连接
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void run(){
        super.run();
        try {
            System.out.println("用户正在连接");
            while (true){
                Socket socket=serverSocket.accept();//利用accept方法阻塞线程，线程会等待socket的输入流
                System.out.println("成功连接");//服务器显示已上线，即线程成功运行
                SendMessUser("你已成功连接至学生签到系统"+'\n',socket);
                SendMessUser("请输入你的学生信息"+'\n'+"学号"+'\t'+"姓名"+'\t'+ "班级",socket);
                list.add(socket);//增加线程数量并记录
                new ReadThread(socket);//这里由于run方法的取消做出了一些更改
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void SendMessUser(String message,Socket socket){//向其他客户发送数据
            if(socket!=null&&socket.isConnected()){//确保客户端没有掉线
                try {
                    OutputStream outputStream=socket.getOutputStream();//输入与输出均要以流的方式进行
                    outputStream.write(message.getBytes());//输出字节流
                    outputStream.flush();//刷新
                }catch (IOException e){
                    e.printStackTrace();
                }
            }

    }
    class ReadThread extends Thread{//读取数据
        InputStream inputStream=null;
        public ReadThread(Socket socket){
            try {
                inputStream=socket.getInputStream();//获取输入流
                byte[] buf=new byte[1024];
                int len = 0;
                if ((len=inputStream.read(buf))!=-1){
                    System.out.println("服务器监听："+'\t'+new String(buf,0,len));//输入流的记录
                }
                if (new Select().main(buf)){//将客户端传递的信息对比数据库，并实现服务端的签到提示
                    SendMessUser(new String(buf,0,len)+'\n'+"已成功签到",socket);
                    System.out.println("该学生信息正确，已成功签到");
                } else {
                    SendMessUser("输入信息有误",socket);
                    System.out.println("查无此人");
                }
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        //这里因为SendMessUser方法有特定的socket参数需求，所以暂时决定取消这个线程，
        //数据流的相关操作均在类中实现，这里不清楚是否有隐患
        /*public void run(){
            super.run();
            try {
                byte[] buf=new byte[1024];
                int len = inputStream.read(buf);
                if ((len=inputStream.read(buf))!=-1){
                    System.out.println("服务器监听："+'\t'+new String(buf,0,len));//输入流的记录
                }
                if (new Select().main(buf)){//判断学生信息是否正确并给出服务端提示
                    System.out.println("该学生信息正确，已成功签到");
                } else {
                    System.out.println("查无此人");
                }
            }catch (IOException e){
                e.printStackTrace();
            }
        }*/
    }
}

