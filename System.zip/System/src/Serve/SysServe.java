package Serve;


import Datebase.SysInsertSignoutTime;
import Datebase.SysInsertTime;
import Datebase.SysSearch;
import Filetransfer.FiletransferClient;
import UI.ServeUi;
import UI.UI2;
import UI.UI4;

import javax.swing.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class SysServe  extends Thread{
    static ServerSocket serverSocket;
    static List<Socket> list = new ArrayList<>();
    ServeUi serveUi = new ServeUi();
    public static void main(String[] args) throws ClassNotFoundException, UnsupportedLookAndFeelException, InstantiationException, IllegalAccessException {
        SysServe sysServe = new SysServe();
        sysServe.run();
    }
    public void run(){
        try {
            System.out.println("正在等待用户连接");
            serverSocket = new ServerSocket(7777);
            while (true){
                Socket socket = serverSocket.accept();
                System.out.println("成功连接");
                list.add(socket);
                SendMessClient("你已经成功连接socket",socket);
                new ReadThreadFromClient(socket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public class ReadThreadFromClient extends Thread{
        InputStream inputStream = null;
        public ReadThreadFromClient(Socket socket){
            try {
                String ipstring = socket.getInetAddress().getHostAddress();
                inputStream = socket.getInputStream();
                byte[] buf = new byte[1024];
                int len = 0;
                if ((len=inputStream.read(buf))!=-1){
                    System.out.println("服务器监听："+'\t'+new String(buf,0,len));
                }
                if (new SysSearch().main(buf)){

                    //此处待添加记录签到时间的功能代码
                    new SysInsertTime().main(ipstring,buf);
                    serveUi.AddAreaText(new String(buf,0,len)+"已签到");
                    SendMessClient(new String(buf,0,len)+'\n'+"已成功签到",socket);
/*                    FiletransferClient filetransferClient = new FiletransferClient();
                    filetransferClient.main();*/
                } else {
                    SendMessClient("别XJB写",socket);
                    new UI2();//登录信息输入错误提示页面弹出
                }
            } catch (IOException | SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public void SendMessClient(String message,Socket socket){//向其他客户发送数据
        if(socket!=null&&socket.isConnected()){//确保客户端没有掉线
            try {
                OutputStream outputStream=socket.getOutputStream();//输入与输出均要以流的方式进行
                outputStream.write(message.getBytes());//输出字节流
                outputStream.flush();//刷新
            }catch (IOException e){
                e.printStackTrace();
            }
        }

    }
}
