package Serve;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ServeTest {
    public static void main(String[] args) {
        Serve serve=new Serve(7777);
        serve.run();
    }
}
