
import java.sql.*;
import java.util.Scanner;

public class Insert {

    public void main(Connection con) {

        try {

            //捕捉控制台输入

            System.out.println("请输入你要插入的实体属性");

            //输入提醒

            System.out.println("id"+'\t'+"name");

            //捕捉控制台输入

            Scanner scanner = new Scanner(System.in);
            String string = scanner.nextLine();
            String[] list = string.split(" ");

            //转换SQL语句

            String sql = "insert into testtable values("+list[0]+","+"'"+list[1]+"'"+")";
            Statement statement = con.createStatement();

            //执行SQL语句

            statement.executeUpdate(sql);

        }  catch (SQLException e) {

            //数据库连接失败异常处理

            e.printStackTrace();

        } finally {

            System.out.println("数据库已完成插入操作");

        }
    }
}
