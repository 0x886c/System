
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Update {

    public static void main(String[] args) throws SQLException {
        //声明Connection对象

        Connection con = null;

        //驱动程序名

        String driver = "com.mysql.jdbc.Driver";

        //URL指向要访问的数据库名login

        String url = "jdbc:mysql://localhost:3306/test";

        //MySQL配置时的用户名

        String user = "root";

        //MySQL配置时的密码

        String password = "123456";

        try {
            Class.forName(driver);

            con = DriverManager.getConnection(url,user,password);

            if (!con.isClosed()){
                System.out.println("已成功连接至本机数据库");
            }
            //创建statement类对象，用来执行SQL语句

            Statement statement = con.createStatement();
            Date date=new Date();
/*            SimpleDateFormat temp=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            String date1=temp.format(date.getTime());
            Date date2=temp.parse(date1)*/;

            Timestamp timeStamp = new Timestamp(date.getTime());
            System.out.println(timeStamp);

            //捕捉控制台输入

            System.out.println("请输入你要更新的id");

            Scanner scanner_id = new Scanner(System.in);

            String string_id = scanner_id.nextLine();

            //转换SQL语句

            String sql = "update studenttable set time='"+timeStamp+"' where id ="+string_id+"";

            //执行SQL

            statement.executeUpdate(sql);

        }  catch (SQLException | ClassNotFoundException e) {

            //数据库连接失败异常处理

            e.printStackTrace();

        } finally {

            System.out.println("数据库已完成查找操作");

        }
    }
}
