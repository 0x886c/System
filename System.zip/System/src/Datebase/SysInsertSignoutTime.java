package Datebase;


import java.sql.*;

import java.util.Date;


public class SysInsertSignoutTime {

    public void main(String ipstring) throws SQLException {
        //声明Connection对象

        Connection con = null;

        //驱动程序名

        String driver = "com.mysql.jdbc.Driver";

        //URL指向要访问的数据库名login

        String url = "jdbc:mysql://localhost:3306/test";

        //MySQL配置时的用户名

        String user = "root";

        //MySQL配置时的密码

        String password = "123456";

        try {
            Class.forName(driver);

            con = DriverManager.getConnection(url,user,password);

            if (!con.isClosed()){
                System.out.println("已成功连接至本机数据库");
            }
            //创建statement类对象，用来执行SQL语句

            Statement statement = con.createStatement();

            //获取当前时间

            Date date=new Date();
            Timestamp timeStamp = new Timestamp(date.getTime());
            System.out.println(timeStamp);

            //转换SQL语句


            String sql = "update studenttable set signouttime = '"+timeStamp+"' where ip = '"+ipstring+"'";

            //sql = "update studenttable set signouttime = '"+timeStamp+"' where ip = '100.64.15.44'";


            //String sql = "update studenttable set signouttime = '"+timeStamp+"' where ip = "+string+"";

            //执行SQL

            statement.executeUpdate(sql);

        }  catch (SQLException | ClassNotFoundException e) {

            //数据库连接失败异常处理

            e.printStackTrace();

        } finally {

            System.out.println("数据库已完成查找操作");

        }
    }
}
