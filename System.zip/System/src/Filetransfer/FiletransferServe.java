package Filetransfer;

import Datebase.SysInsertSignoutTime;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


public class FiletransferServe extends Thread {
    List<Socket> list = new ArrayList<>();
    ServerSocket serverSocket = null;
    public FiletransferServe(){//服务端对象的创建和指定端口的设置
        try {
            serverSocket = new ServerSocket(8888);
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public void run(){
        super.run();
        try {
            System.out.println("用户正在连接");
            while (true){
                Socket socket=serverSocket.accept();//利用accept方法阻塞线程，线程会等待socket的输入流
                System.out.println("成功连接");//服务器显示已上线，即线程成功运行
                list.add(socket);//增加线程数量并记录
                new ReadFile(socket).run();
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public static class ReadFile extends Thread{
        DataInputStream dataInputStream = null;
        FileOutputStream fileOutputStream = null;
        String ipstring = null;
        public ReadFile(Socket socket){
            try {
                ipstring = socket.getInetAddress().getHostAddress();
                dataInputStream = new DataInputStream(socket.getInputStream());
            } catch (IOException e){
                e.printStackTrace();
            }
        }
        public void run(){
            try {
                String fileName = dataInputStream.readUTF();
                File directory = new File("D:\\FiletransferTest");//文件保存路径
                if(!directory.exists()) {
                    directory.mkdir();
                }
                File file = new File(directory.getAbsolutePath() + File.separatorChar +fileName);
                fileOutputStream = new FileOutputStream(file);
                byte[] bytes = new byte[1024];

                int length = 0;

                while((length = dataInputStream.read(bytes, 0, bytes.length)) != -1) {

                    fileOutputStream.write(bytes, 0, length);

                    fileOutputStream.flush();

                }

                System.out.println("文件接收成功 [File Name：" + fileName + "]");

                System.out.println("ipstring:"+ipstring);

                new SysInsertSignoutTime().main(ipstring);



            } catch (Exception e) {

                e.printStackTrace();

            } finally {

                try {

                    if(fileOutputStream != null)

                        fileOutputStream.close();

                    if(dataInputStream != null)

                        dataInputStream.close();


                } catch (Exception e) {}
            }
        }
    }





    public static void main(String[] args) {

        try {

            FiletransferServe filetransferServe =new FiletransferServe(); // 启动客户端
            filetransferServe.run();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}
